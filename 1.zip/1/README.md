# Yescoin vàng

thay query của bạn vào query_id.txt

1. myenv\Scripts\activate

2. aa.py

Tự động nâng cấp level c/k: 	c=yes	k=no

Chia sẻ tool được thu thập từ nhiều nguồn khác nhau. Xem thêm tại https://t.me/toolcodecheat


Lưu ý:
Luôn kiểm tra trước khi sử dụng